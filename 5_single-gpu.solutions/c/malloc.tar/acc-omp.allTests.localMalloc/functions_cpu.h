//Headers of cpu functions

//   initialisation routine
void init(double *restrict U);
